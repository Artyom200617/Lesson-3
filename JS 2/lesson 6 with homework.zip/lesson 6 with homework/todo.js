class ToDoList {
  constructor() {
    this.tasksToDo = [];
    this.button = document.querySelector(".addtodo");

    this.addTodoTask();
    this.renderTask(this.tasksToDo);
  }
  addTodoTask() {
    this.button.addEventListener("click", () => {
      const inputtext = document.querySelector(".inputtext");

      if (inputtext.value == "") {
        alert(" Enter Task Please !!! ");
        return;
      } else {
        const taskText = inputtext.value;
        const newTask = {
          id: this.tasksToDo.length + 1,
          task: taskText,
          isCompleted: false,
        };
        this.tasksToDo.push(newTask);
        inputtext.value = "";
      }
    });
  }

  renderTask(tasksToDo) {
    this.button.addEventListener("click", () => {
      const tasksList = document.querySelector("#tasksList");
      tasksList.innerHTML = "";
      this.tasksToDo.forEach(function ({ id, task, isCompleted }) {
        const tasks = document.createElement("li");
        tasks.setAttribute("id", id);
        tasks.setAttribute("class", "list-group-item task-item");

        const newSpan = document.createElement("span");
        newSpan.innerHTML = task;

        const btn = document.createElement("button");
        btn.setAttribute("class", "btn");
        btn.innerText = "Delete";

        btn.addEventListener("click", () => {
          tasksToDo.splice(id - 1, 1);
          console.log("  this.tasksToDo", tasksToDo);
          btn.parentNode.remove();
        });

        tasks.appendChild(newSpan);
        tasks.appendChild(btn);
        tasksList.appendChild(tasks);
      });
    });
  }
}
const toDoList = new ToDoList();
